
<div class="columnright">
<img src="<?php echo base_url();?>images\petimage.png" style=" height:300px;width:100%">
<div class="cr2">
<h2>Enjoy your Pets in our Island</h2>
<p>
Pet Store offers a special experience on dealing with your pet's needs on the Island. Relax with serenity with all our experts taking care of your pet's needs.
</p>
<ul>
	<li> Grooming </li>
	<li> Vaccines </li>
	<li> Implants </li>
	<li> Dental Cleaning </li>
	<li> Travel Documents </li>
</ul>
