<!DOCTYPE html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Pet Store</title>
<link rel="stylesheet" href="<?php echo base_url();?>css/pet.css" />
</head>

<body id="wrapper">
<div class="row">

<h1 >Pet Store</h1>
<div class="row2">
<div class="columnleft">
<nav>
<a href="<?php echo base_url();?>index.php/login/log" class="plain"> Logout </a><br>


</nav>
</div>
