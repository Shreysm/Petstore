
<p >
	Pet Store <br>
	1999 All Pets Road <br>
	Round Rock,TX 9555<br>
</p>
<p>
<a href="tel:888-555-5555" id="plain">888-555-5555</a>
</p>

<address>Copyright &copy 2018 Pacific Trails Resort<br>
<a href="mailto:shrey31.sm@gmail.com">shreyas@mohan.com</a>
</address>
<br>
</div>
</div>
</div>
</div>
</body>
</html>
