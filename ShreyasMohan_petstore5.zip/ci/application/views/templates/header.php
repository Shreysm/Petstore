<!DOCTYPE html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Pet Store</title>
<link rel="stylesheet" href="<?php echo base_url();?>css/pet.css" />
</head>

<body id="wrapper">
<div class="row">

<h1 >Pet Store</h1>
<div class="row2">
<div class="columnleft">
<nav>
<a href="<?php echo base_url();?>index.php/pethome/index" class="plain"> Home </a><br>

<a href="<?php echo base_url();?>index.php/pethome/about" class="plain"> About Us </a><br>

<a href="<?php echo base_url();?>index.php/contact/contacts" class="plain"> Contact Us </a><br>

<a href="<?php echo base_url();?>index.php/client/clients" class="plain"> Client </a><br>

<a href="<?php echo base_url();?>index.php/service/services" class="plain"> Service </a><br>

<a href="<?php echo base_url();?>index.php/login/log" class="plain"> Login </a><br>
</nav>
</div>
