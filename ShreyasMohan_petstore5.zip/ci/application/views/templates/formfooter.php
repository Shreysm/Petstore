<address>Copyright &copy 2018 Pet Store<br>
<a href="mailto:shrey31.sm@gmail.com">shreyas@mohan.com</a>
</address>
</div>
</div>
</div>
</div>

</body>
</html>