
<div class="columnright">

<img src="<?php echo base_url();?>images\petimage3.png" style=" height:300px;width:100%">
<div class="cr2" >

<h2>About Us</h2>
<p>
We specialize in offering site services to Pet Store. We offer a one stop store for clients and businesses. Pet Store offers a special experience on dealing with your pet's needs on the Island. Relax with serenity with all our experts taking care of your pet's needs.
</p>
