<?php 
echo "Hello World";
?>